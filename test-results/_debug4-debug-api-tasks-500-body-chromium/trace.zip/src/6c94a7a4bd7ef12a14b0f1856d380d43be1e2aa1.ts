import { test } from "@playwright/test";
import { login } from "./fixtures";

test("debug: /api/tasks 500 body", async ({ page }) => {
  await login(page, "SUPER_ADMIN");
  const res = await page.request.get("http://localhost:5000/api/tasks", {
    headers: { cookie: (await page.context().cookies()).map(c => `${c.name}=${c.value}`).join("; ") },
  });
  console.log("status:", res.status());
  console.log("body:", await res.text());
});
